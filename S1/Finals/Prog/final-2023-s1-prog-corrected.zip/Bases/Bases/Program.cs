﻿using System;
using System.ComponentModel;

namespace Bases
{
    internal class Program
    {
        public static void HelloName(string name)
        {
            if (name == null || name.Equals(""))
                name = "World";
            
            Console.WriteLine("Hello " + name + "!");
        }

        public static void PrintFibo(uint n)
        {
            uint a = 0;
            uint b = 1;

            for (uint i = 0; i < n; i++)
            {
                Console.WriteLine(a);
                uint tmp = a;
                a = b;
                b += tmp;
            }
            
            Console.WriteLine(a);
        }

        public enum BASE
        {
            BINARY = 2,
            OCTAL = 8,
            DECIMAL = 10
        }

        public static string ItoaBase(uint n, BASE b)
        {
            string str = "";

            for (; n > 0; n /= (uint) b)
            {
                char c = (char) ('0' + (n % (uint) b));
                str = c + str;
            }

            return str;
        }
    }
}