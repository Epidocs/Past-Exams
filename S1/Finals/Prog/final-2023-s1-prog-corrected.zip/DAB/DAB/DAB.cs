using System;

namespace DAB
{
    public class DAB
    {
        public uint uid { get; }
        private static uint dabCount;
        
        public readonly Bank bank;
        private uint moneyLeft { get; set; }

        public DAB(Bank bank)
        {
            this.bank = bank;
            uid = dabCount++;
        } 

        public void Fill(uint amount)
        {
            moneyLeft += amount;
        }

        public bool AllowWithdraw(User user, uint amount)
        {
            return bank == user.bank && moneyLeft >= amount && bank.AllowWithdraw(user, amount);
        }

        public void Withdraw(User user, uint amount)
        {
            moneyLeft -= amount;
            bank.Withdraw(user, amount);
        }

        public bool AllowDeposit(User user)
        {
            return bank == user.bank;
        }

        public void Deposit(User user, uint amount)
        {
            moneyLeft += amount;
            bank.Deposit(user, amount);
        }

        public void DisplayDABInfo()
        {
            Console.WriteLine("=== DAB Information ===");
            Console.WriteLine("UID: " + uid);
            Console.WriteLine("Bank: " + bank.name);
            uint integerPart = moneyLeft / 100;
            uint decimalPart = moneyLeft % 100;
            Console.WriteLine("Money left: " + integerPart + "." + decimalPart + "EUR");
        }
    }
}