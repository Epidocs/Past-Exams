using System;

namespace DAB
{
    public class Inputs
    {
        private static DAB[] dabs;
        private static Bank[] banks;
        private static User[] users;

        public static void Init()
        {
            // Init variables
            banks = new[]
            {
                new Bank("EPITA"),
                new Bank("ACDC"),
            };

            dabs = new[]
            {
                new DAB(banks[0]),
                new DAB(banks[0]),
                new DAB(banks[1]),
            };
            
            users = new[]
            {
                new User("Sophie"),
                new User("Calcifer"),
                new User("Navet"),
            };
            
            // Init contents
            dabs[0].Fill(30000);
            dabs[1].Fill(50000);
            dabs[2].Fill(100000);
            
            banks[0].AddUser(users[0]);
            banks[1].AddUser(users[1]);
            banks[1].AddUser(users[2]);
        }
        
        public static string GetString(string text)
        {
            string res;
            
            do
            {
                Console.Write(text + ": ");
                res = Console.ReadLine();
            } while (res == "");

            return res;
        }

        public static uint GetUInt(string text)
        {
            while (true)
            {
                Console.Write(text + ": ");
                
                uint res;
                string line = Console.ReadLine();
                
                if (UInt32.TryParse(line, out res))
                    return res;
            }
        }

        public static User GetUser()
        {
            while (true)
            {
                string name = GetString("User name");

                foreach (User user in users)
                    if (user.name.Equals(name))
                        return user;
            }
        }

        public static DAB GetDAB()
        {
            while (true)
            {
                uint uid = GetUInt("DAB uid");

                foreach (DAB dab in dabs)
                    if (dab.uid == uid)
                        return dab;
            }
        }

        public static Bank GetBank()
        {
            while (true)
            {
                string name = GetString("Bank name");

                foreach (Bank bank in banks)
                    if (bank.name.Equals(name))
                        return bank;
            }
        }
    }
}