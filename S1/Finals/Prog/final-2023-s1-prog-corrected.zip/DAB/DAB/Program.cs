﻿using System;

namespace DAB
{
    internal class Program
    {
        private static void HandleDeposit()
        {
            User user = Inputs.GetUser();
            DAB dab = Inputs.GetDAB();
            uint amount = Inputs.GetUInt("Amount");

            if (dab.AllowDeposit(user))
            {
                dab.Deposit(user, amount);
                Console.WriteLine("Operation successful!");
            }
            else
                Console.WriteLine("Error: Wrong bank.");
        }

        private static void HandleWithdraw()
        {
            User user = Inputs.GetUser();
            DAB dab = Inputs.GetDAB();
            uint amount = Inputs.GetUInt("Amount");
            
            if (dab.AllowWithdraw(user, amount))
            {
                dab.Withdraw(user, amount);
                Console.WriteLine("Operation successful!");
            }
            else
                Console.WriteLine("Error: Wrong bank or not enough money.");
        }

        private static void HandleUserInfo()
        {
            User user = Inputs.GetUser();
            user.DisplayUserInfo();
        }

        private static void HandleDABInfo()
        {
            DAB dab = Inputs.GetDAB();
            dab.DisplayDABInfo();
        }

        private static void HandleBankInfo()
        {
            Bank bank = Inputs.GetBank();
            bank.DisplayBankInfo();
        }
        
        public static void Main(string[] args)
        {
            Inputs.Init();
            
            Console.WriteLine("Welcome!");
            
            while (true)
            {
                uint mainMenu = Menus.SelectMainMenu();

                switch (mainMenu)
                {
                    case 1:
                        HandleDeposit();
                        break;
                    case 2:
                        HandleWithdraw();
                        break;
                    case 3:
                        HandleUserInfo();
                        break;
                    case 4:
                        HandleDABInfo();
                        break;
                    case 5:
                        HandleBankInfo();
                        break;
                    case 6:
                        Console.WriteLine("Goodbye!");
                        return;
                }
                
                Console.Read();
            }
        }
    }
}