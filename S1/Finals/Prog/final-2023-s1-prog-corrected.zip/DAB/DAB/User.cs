using System;

namespace DAB
{
    public class User
    {
        public string name { get; }
        public Bank bank { get; private set; }

        public User(string name)
        {
            this.name = name;
        }

        public void JoinBank(Bank bank)
        {
            this.bank = bank;
        } 

        public void DisplayUserInfo()
        {
            Console.WriteLine("=== User Information ===");
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Bank: " + bank.name);
            uint money = bank.GetMoneyOf(this);
            uint integerPart = money / 100;
            uint decimalPart = money % 100;
            Console.WriteLine("Money: " + integerPart + "." + decimalPart + "EUR");
        }
    }
}