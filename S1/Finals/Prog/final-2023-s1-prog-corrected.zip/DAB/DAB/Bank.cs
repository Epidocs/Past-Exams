using System;
using System.Collections.Generic;

namespace DAB
{
    public class Bank
    {
        public string name { get; }
        private Dictionary<User, uint> users;

        public Bank(string name)
        {
            this.name = name;
            
            users = new Dictionary<User, uint>();
        }

        public void AddUser(User user)
        {
            users.Add(user, 0);
            user.JoinBank(this);
        }

        public bool AllowWithdraw(User user, uint amount)
        {
            uint userMoney;
            
            if (!users.TryGetValue(user, out userMoney))
                return false;
            
            return amount <= userMoney;
        }

        public void Withdraw(User user, uint amount)
        {
            users[user] -= amount;
        }

        public void Deposit(User user, uint amount)
        {
            users[user] += amount;
        }

        public uint GetMoneyOf(User user)
        {
            foreach (var localUser in users)
                if (localUser.Key == user)
                    return localUser.Value;
            return 0;
        }

        public void DisplayBankInfo()
        {
            Console.WriteLine("=== Bank Information ===");
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Users:");
            foreach (var user in users)
            {
                uint integerPart = user.Value / 100;
                uint decimalPart = user.Value % 100;
                Console.WriteLine("- " + user.Key.name + ": " + integerPart + "." + decimalPart + "EUR");
            }
        }
    }
}