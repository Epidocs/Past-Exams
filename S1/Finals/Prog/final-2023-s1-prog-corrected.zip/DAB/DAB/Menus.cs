using System;

namespace DAB
{
    public class Menus
    {
        public static uint SelectMainMenu()
        {
            Console.Clear();
            
            uint selected;
            do
            {
                Console.WriteLine("Select an action:");
                Console.WriteLine("1. Deposit");
                Console.WriteLine("2. Withdraw");
                Console.WriteLine("3. Person info");
                Console.WriteLine("4. DAB info");
                Console.WriteLine("5. Bank info");
                Console.WriteLine("6. Quit");

                selected = Inputs.GetUInt("Choice");

            } while (selected < '0' && '6' < selected);
            
            Console.Clear();

            return selected;
        }
    }
}